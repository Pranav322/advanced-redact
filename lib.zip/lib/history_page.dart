import 'package:flutter/material.dart';

class HistoryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'History Page',
        style: Theme.of(context).textTheme.headlineMedium,
      ),
    );
  }
}